# Kolasys AI — Development Session Documentation
**Date:** Friday, April 17, 2026  
**Time:** 11:00 AM – ~1:30 PM EDT  
**Session Type:** Infrastructure, UI Redesign, Competitive Analysis  

---

## Table of Contents
1. [Session Overview](#session-overview)
2. [Railway Production Setup](#railway-production-setup)
3. [Environment Variable Fixes](#environment-variable-fixes)
4. [UI Redesign — Dark Mode & Glass UI](#ui-redesign)
5. [Competitive Analysis — Fireflies Settings Audit](#competitive-analysis)
6. [Feature Gap Analysis](#feature-gap-analysis)
7. [Apple Watch Strategy](#apple-watch-strategy)
8. [Pending Build Queue](#pending-build-queue)
9. [Technical Notes & Reminders](#technical-notes)

---

## 1. Session Overview

This session accomplished three major workstreams:
- **Permanently moved background workers from local Mac to Railway cloud** (both transcription + summarization workers now run 24/7 without needing the Mac to be on)
- **Full UI redesign** with dark mode, glass UI, and gradient stat cards deployed to `feat/ui-redesign` branch (pending merge to main)
- **Deep competitive analysis** of Fireflies.ai (all settings pages, meeting detail layout, features) to build a comprehensive feature roadmap

---

## 2. Railway Production Setup

### Problem
Both `transcription.worker.ts` and `summarization.worker.ts` were running locally on the developer's Mac. If the Mac went to sleep or was turned off, the entire AI pipeline stopped processing.

### Solution
Two separate Railway services were created and configured.

### Service 1: `kolasys-ai` (Transcription Worker)
- **Railway Project:** glorious-serenity
- **Service ID:** `696565c8-cf22-4eb2-91c6-1cb50e25ee98`
- **Source Repo:** `kolasystems/kolasys-ai` (main branch)
- **Start Command:** `npx tsx src/workers/transcription.worker.ts`
- **Region:** us-west2
- **Status:** ✅ Online, heartbeating every 60 seconds
- **Log pattern:** `[transcription] alive — processed N jobs, last job: none/timestamp`

### Service 2: `summarization-worker`
- **Railway Project:** glorious-serenity (same project)
- **Service ID:** `22ddb72d-8f94-4023-ae09-456d1f6b2e10`
- **Source Repo:** `kolasystems/kolasys-ai` (main branch)
- **Start Command:** `npx tsx src/workers/summarization.worker.ts`
- **Region:** us-west2
- **Status:** ✅ Online, heartbeating every 60 seconds
- **Log pattern:** `[summarization] alive — processed N jobs, last job: none/timestamp`

### Steps Taken
1. Opened Railway project → clicked existing `kolasys-ai` service
2. Went to **Settings → Deploy** → changed Start Command from running both workers to only `npx tsx src/workers/transcription.worker.ts`
3. Went to **Variables** → **Raw Editor** → copied all 27 env vars
4. Fixed critical bug: `NEXT_PUBLIC_APP_URL` was set to `http://localhost:3000` — changed to `https://app.kolasys.ai` on BOTH services
5. Clicked **+ Add → GitHub Repository → kolasystems/kolasys-ai** to create second service
6. Renamed from Railway auto-name (`inspiring-victory`) to `summarization-worker`
7. Set Start Command: `npx tsx src/workers/summarization.worker.ts`
8. Pasted all 27 env vars via Raw Editor (JavaScript clipboard automation)
9. Deployed both — both reached **ACTIVE / Deployment successful** within ~5 minutes

### Why `NEXT_PUBLIC_APP_URL` Was Critical
The workers use this URL to call the tRPC API after completing jobs (to update recording status, enqueue next pipeline step). With `localhost:3000`, workers were completing jobs but couldn't call back to the app — causing silent failures in the pipeline.

### Local Development Going Forward
Developers still need 3 terminals for local dev:
```bash
# Terminal 1
npm run dev

# Terminal 2  
npx tsx src/workers/transcription.worker.ts

# Terminal 3
npx tsx src/workers/summarization.worker.ts
```
Local `.env` must keep `NEXT_PUBLIC_APP_URL=http://localhost:3000`. Railway services have `https://app.kolasys.ai`. The two environments don't conflict because they both pull from the same Upstash Redis queue — whichever worker picks up a job first processes it.

---

## 3. Environment Variable Fixes

### Clerk Key Mismatch (Local Dev)
**Problem:** Local `.env` had mismatched Clerk keys:
- `NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY=pk_test_...` (test instance)
- `CLERK_SECRET_KEY=sk_live_...` (production instance)

These keys are from two different Clerk instances and cannot be used together. This caused `Clerk: Handshake token verification failed: jwk-kid-mismatch` errors.

**Fix Applied:**
```bash
# Changed CLERK_SECRET_KEY to match the test publishable key:
CLERK_SECRET_KEY=sk_test_80j6IIBu0Rm3dYD1JGSbc1geQqWDFnXZiNc4gEhb6t
```

**Rule Going Forward:**
- Local `.env` → test keys ONLY (`pk_test_` + `sk_test_`)
- Railway production → live keys (`pk_live_` + `sk_live_`)
- Never mix test publishable key with live secret key

### Cookie Conflict Resolution
When switching Clerk instances locally, old HttpOnly session cookies in the browser conflict with the new instance. These cannot be cleared via JavaScript. Solution: `Cmd+Shift+Delete` in Chrome → clear cookies for localhost.

---

## 4. UI Redesign — Dark Mode & Glass UI

### Branch
`feat/ui-redesign` — NOT yet merged to main at end of session (pending final review sign-off)

### Files Modified

#### `src/app/layout.tsx`
- Added inline `<script>` tag in `<head>` for pre-hydration dark mode
- Script reads `localStorage.getItem('kolasys-theme')` and adds `dark` class to `<html>` before first paint
- Prevents flash of wrong theme on hard reload and across page navigations
```javascript
(function() {
  try {
    var theme = localStorage.getItem('kolasys-theme');
    if (theme === 'dark') document.documentElement.classList.add('dark');
  } catch(e) {}
})();
```

#### `src/app/globals.css`
- Added CSS custom properties for light and dark theme tokens
- Light: `--bg: #F8F9FC`, `--surface: #FFFFFF`, `--border: #E5E7EB`
- Dark: `--bg: #0F0F13`, `--surface: #1A1A24`, `--border: rgba(255,255,255,0.08)`
- Accent: `--accent: #5B8DEF` (same both modes)
- Added `.glass` utility class:
  ```css
  /* Dark mode */
  background: rgba(255,255,255,0.05);
  backdrop-filter: blur(20px);
  border: 1px solid rgba(255,255,255,0.08);
  border-radius: 16px;
  
  /* Light mode */
  background: rgba(255,255,255,0.7);
  backdrop-filter: blur(20px);
  border: 1px solid rgba(0,0,0,0.06);
  ```

#### `src/components/dark-mode-toggle.tsx`
- Added to sidebar bottom with sun/moon icon
- Stores preference in `localStorage` key `kolasys-theme`
- Applies/removes `dark` class on `document.documentElement`
- **Toggle label shows DESTINATION** (not current state):
  - In dark mode → shows "Light mode" + Sun icon
  - In light mode → shows "Dark mode" + Moon icon

#### `src/app/dashboard/page.tsx` (Dashboard Overview)
- Replaced plain stat cards with `GradientStatCard` components
- 4 gradient cards:
  - Total Recordings: `#667eea → #764ba2` (purple)
  - Meeting Notes: `#f093fb → #f5576c` (pink/red)
  - Open Action Items: `#4facfe → #00f2fe` (blue/cyan)
  - Completed Tasks: `#43e97b → #38f9d7` (green/teal)
- Fixed RSC error: Lucide icon components cannot be passed as props from Server Components — resolved by passing icon name string and resolving via lookup map inside client component

#### `src/app/dashboard/recordings/page.tsx`
- Added dark: variants on recording cards
- Glass morphism hover effect: `translateY(-2px)` + box-shadow glow
- Status badge dark variants: READY=emerald, PENDING=amber, FAILED=red
- Skeleton loaders with shimmer animation in dark mode

#### `src/app/dashboard/action-items/page.tsx`
- Full dark mode audit — every element themed:
  - Page background: `dark:bg-[#0F0F13]`
  - Cards: `dark:bg-[#1A1A24] dark:border-white/10`
  - Titles: `dark:text-white`
  - Descriptions: `dark:text-gray-400`
  - "From:" metadata: `dark:text-gray-500`
  - Group headings: `dark:text-gray-300`
- Priority pills with dark-aware variants:
  - LOW: `dark:bg-white/5 dark:text-gray-400`
  - MEDIUM: `dark:bg-blue-500/15 dark:text-blue-200`
  - HIGH: `dark:bg-orange-500/15 dark:text-orange-200`
  - URGENT: `dark:bg-red-500/15 dark:text-red-200`

#### `src/app/dashboard/calendar/page.tsx`
- Dark: variants on header, empty states, banners
- Microsoft Outlook stub card: `dark:bg-[#1A1A24] dark:border-white/10`
- Code tags: `dark:bg-white/10 dark:text-gray-300`
- Success/error banners: dark-aware amber/green/red variants

#### `src/app/dashboard/search/page.tsx` (Ask AI)
- Header bar: `dark:bg-[#1A1A24] dark:border-white/10`
- Sparkles icon container: `dark:bg-accent/15`
- Suggested question cards: `dark:bg-[#1A1A24] dark:border-white/10 dark:hover:border-accent/50`
- Chat bubbles: user stays brand-600, AI bubbles: `dark:bg-[#1A1A24]`
- Input bar: `dark:bg-white/5 dark:border-white/10`
- Citation cards: `dark:border-white/10 dark:bg-white/5`

#### `src/app/dashboard/settings/page.tsx`
- Heading: `dark:text-white` (was invisible before fix)
- Workspace/Account sections: `dark:bg-[#1A1A24] dark:border-white/10`
- Row helper: `dark:text-gray-400` / `dark:text-white`
- Section dividers: `dark:divide-white/10`
- Templates link card: `dark:hover:border-accent/50 dark:hover:bg-accent/10`
- Coming soon cards: `dark:bg-[#1A1A24]`
- "Coming soon" badges: `dark:bg-white/10 dark:text-gray-300`

#### `src/components/audio-retention-toggle.tsx`
- Container: `dark:bg-[#1A1A24] dark:border-white/10`
- Toggle switch track: `dark:bg-white/15` (when off)
- Warning banner: `dark:border-amber-500/30 dark:bg-amber-500/10 dark:text-amber-200`
- Feedback pills: dark-aware success/error variants

### Build Result
```
✓ Compiled successfully in 7.1s
```
Zero TypeScript errors, zero build warnings.

### Dark Theme Color Reference
| Token | Value | Usage |
|-------|-------|-------|
| Page background | `#0F0F13` | `dark:bg-[#0F0F13]` |
| Card/surface | `#1A1A24` | `dark:bg-[#1A1A24]` |
| Border | `rgba(255,255,255,0.08)` | `dark:border-white/10` (≈8%) |
| Primary text | `#F9FAFB` | `dark:text-white` |
| Secondary text | `#9CA3AF` | `dark:text-gray-400` |
| Muted text | `#6B7280` | `dark:text-gray-500` |
| Accent | `#5B8DEF` | `dark:text-accent` |
| Sidebar gradient | `#0F0F13 → #1A1A24` | vertical gradient |

---

## 5. Competitive Analysis — Fireflies.ai

Paul's account was used to do a live exploration of all Fireflies features.

### Navigation Structure (Fireflies Sidebar)
- Home
- Meetings (notebook)
- Meeting Status
- Uploads
- Integrations
- Analytics *(paid — Business plan)*
- Voice Agents *(NEW)*
- AI Skills
- Team
- Upgrade
- Settings
- More

### Meeting Detail Layout
Fireflies uses a **split-pane layout** — significantly better than tabs:
- **Left pane:** Notes/Summary with timestamped sections + "Refine Summary" button + "AI Skills" button
- **Right pane:** Three tabs: Transcript | AskFred | AI Skills
- **Bottom:** Persistent audio player (play/pause, ±15s skip, 1x speed, download)
- **Top:** Breadcrumb (`#All Meetings / meeting title`), Share button, `...` overflow menu
- **Right panel header:** "Find or Replace" search in transcript

### Settings Pages — Full Audit

#### Personal Settings

| Page | Key Features |
|------|-------------|
| **Recording & Privacy** | Auto-record meetings toggle, record all calendar events with meeting link, Capture meeting video (paid), Meeting language dropdown, Auto-delete meetings (paid), Meeting privacy (teammates/anyone/only me), Who gets post-meeting email, What to include in email (overview/transcript/etc), Meeting-prep email (1hr before recurring meetings), Recording rules (record if title matches keywords), Restriction rules (don't record if title matches keywords) |
| **Compliance Notification** | Notify participants when recording starts, custom notification message text |
| **AI Settings** | Who can access your AI Skills (only me/team), Topic Tracker (add keywords to highlight in transcripts — 15 voice commands configured), Custom vocabulary (add domain-specific terms to improve transcription accuracy) |
| **Live Meeting** | Live captions, live AI assistant (requires desktop app) — content gated |
| **Knowledge Base** | Upload documents for AI to reference — shown in sidebar but content not accessible on Pro plan |
| **Developer Settings** | API keys, webhooks — content gated/empty |
| **Cookies & Analytics** | Standard privacy preferences |

#### Team Settings

| Page | Key Features |
|------|-------------|
| **Recording & Privacy** | Override recording settings org-wide, allow teammates to choose their own settings |
| **Integrations** | CRM, Slack, Notion for entire team |
| **Rules** | Org-wide recording and restriction rules |

#### Account/Billing

| Page | Key Features |
|------|-------------|
| **Members & Groups** | Invite members, create groups, manage roles |
| **AI Credits** | Usage tracking |
| **Billing** | Pro Plan: $18/seat billed monthly, subscription management |
| **Account** | Team name edit, plan display, Leave Team, Delete account |

### AI Skills Page
Three tabs:
- **Discover** — browse skills by category (All Skills, Sales, Finance, HR, More), search, + Create button
- **Active Skills (2)** — skills currently applied to all new meetings
- **Feed** — recent skill outputs across meetings

Top picks shown: 1:1, Idea Generator, Daily Standups
Sales category shown: RANT, Churn Risk detector

### Home Page Features
- "Good Evening, Paul" personalized greeting
- **12 Tasks** quick stats card
- **4 AI Skills** quick stats card
- **120 Contacts** quick stats card (auto-extracted from all meetings)
- Personal Assistant section with 3 cards: Daily Digest, Meeting Prep, Popular Topics
- Recent Meetings feed with action item previews
- Global Ask AI search box at bottom

---

## 6. Feature Gap Analysis

### Features Kolasys is Missing vs. All Competitors

| Feature | Competitor | Priority | Effort |
|---------|-----------|----------|--------|
| **Split-pane layout** (notes left, transcript right) | Fireflies | 🔴 Critical | Medium |
| **Conversation Intelligence** (talk time %, filler words, sentiment, meeting score) | Read.ai, Fireflies | 🔴 Critical | High |
| **Semantic search across ALL recordings** | Fireflies, Otter | 🔴 Critical | High |
| **Post-meeting email** (summary to attendees) | Fireflies, Fathom | 🔴 Critical | Low |
| **Refine Summary** (condense/elaborate AI button) | Fireflies | 🟠 High | Low |
| **Word-level audio sync** (click word → jump to timestamp) | Otter.ai | 🟠 High | Medium |
| **Daily Digest** (in-app + email) | Fireflies, Read.ai | 🟠 High | Medium |
| **Contacts** (auto-extract people from meetings) | Fireflies | 🟠 High | Medium |
| **Custom vocabulary** (improve transcription accuracy) | Fireflies | 🟠 High | Low |
| **Compliance notification** (notify when recording starts) | Fireflies | 🟠 High | Low |
| **Topic Tracker** (keyword highlighting across transcripts) | Fireflies | 🟠 High | Medium |
| **Meeting Status page** | Fireflies | 🟡 Medium | Low |
| **API Keys** (replace "Coming soon") | Fireflies | 🟡 Medium | Medium |
| **Knowledge Base** (upload docs for AI context) | Fireflies (Business) | 🟡 Medium | High |
| **Shareable highlight clips** (Soundbites) | Fireflies, Fathom | 🟡 Medium | Medium |
| **CRM integration** (Salesforce, HubSpot) | Fireflies, Fathom | 🟡 Medium | High |
| **Team workspace** (shared feed, org analytics) | Fireflies, Otter | 🟡 Medium | High |
| **Zapier/Make webhooks** | Fireflies, Fathom | 🟡 Medium | Low |
| **Analytics page** (talk time, frequency, sentiment) | Read.ai, Fireflies | 🟡 Medium | High |
| **Recording rules** (auto-record by title keywords) | Fireflies | 🟡 Medium | Medium |
| **Meeting prep email** (1hr before meeting) | Fireflies | 🟡 Medium | Medium |
| **Voice Agents** | Fireflies | 🔵 Future | Very High |
| **Live captions** | Otter, Zoom AI | 🔵 Future | Very High |
| **AI Skills marketplace** | Fireflies | 🔵 Future | High |
| **Billing page** (Stripe integration) | All | 🔵 Future | High |
| **Members & groups management** | All | 🔵 Future | Medium |

### Biggest Differentiator Opportunity
**Knowledge Base** — None of the competitors offer this at an affordable price point. Fireflies locks it behind Business tier ($29+/seat). Kolasys could offer it as a standard feature:
- Upload company SOPs, product docs, org charts, contact lists
- Every meeting summary and AI answer draws from that context
- AI notes become dramatically more accurate and relevant

---

## 7. Apple Watch App Strategy

None of Kolasys's competitors have an Apple Watch app. This is a major differentiator opportunity.

### Proposed Features

#### Recording Control
- Tap Crown → start/stop recording on iPhone from wrist
- Live recording timer on watch face
- Waveform animation while actively recording
- Haptic confirmation when recording starts/stops

#### Meeting Awareness
- Calendar complication showing "Next meeting in Xm"
- Tap notification → pre-loads recording screen on iPhone
- "Start recording this meeting" action from notification

#### Post-Meeting Notifications
- Wrist notification when notes are ready (~2-5 min after meeting)
- Quick summary: 3-5 bullet points rendered on watch
- Action items list — tap to mark complete from wrist
- "Share notes" Siri shortcut

#### Real-Time During Meeting
- Discrete Force Touch → bookmark this moment (creates timestamp in transcript)
- Silent haptic alert at 60-minute mark
- Live speaker names as they speak (if connected to bot)

### Technical Stack
- **WatchOS app:** SwiftUI
- **Communication:** WatchConnectivity framework (watch ↔ iPhone)
- **iPhone companion:** Native Swift extension of the Expo app
- **Scaffolding:** Claude Code can generate the initial SwiftUI app

### Build Plan
1. Claude Code scaffolds SwiftUI WatchOS target in Xcode
2. WatchConnectivity session between watch and iOS Expo app
3. Simple recording control as MVP (start/stop + timer)
4. Phase 2: post-meeting notification with summary bullets
5. Phase 3: bookmark moments, action item management

---

## 8. Pending Build Queue

In priority order (agreed at end of session):

### 1. ✅ DONE — Dark Mode + Glass UI (feat/ui-redesign branch)
Needs: merge to main → push → Vercel auto-deploys

### 2. 🔜 NEXT — Split-Pane Recording Detail Layout
**Goal:** Replace tabs with side-by-side layout
- Left (60%): Notes/Summary with "Refine Summary" button
- Right (40%): Transcript | Ask AI tabs
- Both panels independently scrollable
- Responsive: collapses to tabs on mobile

### 3. Conversation Intelligence (Analytics)
- Talk time per speaker (pie chart + bar chart)
- Filler word count ("um", "like", "you know")
- Sentiment score per meeting (positive/neutral/negative)
- Meeting score (0-100)
- Accessible at `/dashboard/analytics`

### 4. Post-Meeting Email
- Send summary to meeting host automatically
- Toggle: send to all participants / host only / disabled
- Setting in `/dashboard/settings`
- Uses existing Resend integration

### 5. Refine Summary Button
- "Condense" → shorter, tighter summary
- "Elaborate" → more detail, expand bullet points
- Appears on recording detail notes pane

### 6. Custom Vocabulary
- User adds domain-specific terms
- Passed to Whisper as prompt context for better transcription
- Setting in `/dashboard/settings`

### 7. Contacts Page
- Auto-extract people mentioned across all recordings
- Name, org, first mentioned, last mentioned, meeting count
- `/dashboard/contacts`

### 8. Daily Digest
- In-app notification + email
- Summary of yesterday's meetings
- Action items still open
- Scheduled via existing Resend + cron

### 9. API Keys
- Replace "Coming soon" with real key generation
- Store hashed keys in DB
- Rate limiting per key
- Webhook support

### 10. Mobile UI Redesign
- Same dark mode + glass UI applied to Expo app
- expo-blur for glass effects
- AsyncStorage for theme persistence
- LinearGradient headers

### 11. Apple Watch App
- SwiftUI + WatchConnectivity
- Phase 1: recording control only
- Phase 2: post-meeting notifications

---

## 9. Technical Notes & Reminders

### Prisma v7 Rules
- No `$transaction` — use sequential calls
- No nested creates
- Import: `from '@/generated/prisma/client'`

### Next.js 16 Rules
- `params` and `searchParams` are `Promise<{}>` — always `await params`
- Middleware lives in `src/proxy.ts`
- Server Components cannot pass non-serializable objects (like Lucide icons) as props to Client Components — pass string name instead and resolve with lookup map

### Worker Rules
- Workers need `import 'dotenv/config'` as FIRST import
- Both workers log heartbeat every 60 seconds to Railway deploy logs
- Graceful SIGTERM shutdown implemented

### Mobile Rules
- Always `npm install --legacy-peer-deps`
- Never upgrade react-native-safe-area-context, -screens, -gesture-handler independently
- `getToken` must be in `useRef` (causes infinite loop otherwise)
- `expo-file-system/legacy` import for `cacheDirectory`
- tRPC batch POST body format: `{"0":{json:input}}` not array

### Services & Credentials
| Service | Purpose |
|---------|---------|
| Neon | PostgreSQL database |
| Clerk | Authentication (test: `pk_test_` / `sk_test_`, prod: `pk_live_` / `sk_live_`) |
| Upstash | Redis / BullMQ queue |
| AWS S3 | Audio file storage (bucket: `kolasys-ai-audio`) |
| OpenAI | Whisper transcription + embeddings |
| Anthropic | Claude AI (summarization, Ask AI) |
| Vercel | Web hosting (auto-deploys from `main` branch) |
| Railway | Background workers (transcription + summarization) |
| Cloudflare | DNS |
| Resend | Email (from: `Kolasys AI <onboarding@resend.dev>`) |
| Sentry | Error monitoring |
| PostHog | Product analytics |

### Git Branch Strategy
- `main` → production (app.kolasys.ai via Vercel)
- `feat/*` → feature branches, tested locally before merge
- Never commit directly to main without local testing

### Railway Environment Variables (both services)
All 27 vars copied from `kolasys-ai` service. Key difference:
- `NEXT_PUBLIC_APP_URL=https://app.kolasys.ai` (NOT localhost)

---

## Session Timeline

| Time (EDT) | Activity |
|-----------|---------|
| ~11:00 AM | Noticed `kolasys-ai` Railway service deploying |
| 11:10 AM | Identified `NEXT_PUBLIC_APP_URL=localhost` bug in Railway |
| 11:20 AM | Fixed URL in `kolasys-ai` service, deployed |
| 11:30 AM | Created `summarization-worker` service on Railway |
| 11:35 AM | Renamed service, set start command |
| 11:40 AM | Pasted 27 env vars via Raw Editor clipboard automation |
| 11:50 AM | Both workers confirmed Online + heartbeating |
| 11:55 AM | Stopped local workers on Mac |
| 12:00 PM | Started UI review — Clerk key mismatch discovered |
| 12:05 PM | Fixed Clerk key mismatch in local `.env` |
| 12:10 PM | Browser cookie conflict — cleared manually |
| 12:15 PM | Reviewed new UI — 6 RSC prop errors found |
| 12:20 PM | Claude Code fixed Lucide icon RSC prop issues |
| 12:25 PM | Reviewed dark mode — identified 5 issues |
| 12:30 PM | Claude Code fixed all dark mode issues across all pages |
| 12:45 PM | Explored Fireflies.ai — home, meeting detail, AI Skills |
| 1:00 PM | Explored all Fireflies settings pages (Personal + Team + Billing) |
| 1:15 PM | Dark mode review passed — all pages approved |
| 1:20 PM | Discussed Apple Watch strategy |
| 1:25 PM | Agreed on feature priority build queue |
| 1:30 PM | Documentation session (this file) |

---

*Document generated: Friday, April 17, 2026, ~1:30 PM EDT*  
*Next session: Split-pane recording detail layout + mobile UI redesign*
